// Modules to control application life and create native browser window
const {app, BrowserWindow, Notification, session, ipcMain, dialog, globalShortcut} = require('electron');
const path = require('path');
const fs = require('fs');

let mainWindow;

function createWindow () {
  // Create the browser window.
  mainWindow = new BrowserWindow({
    width: 1024,
    height: 768,
    webPreferences: {
      preload: path.join(__dirname, 'preload.js')
    }
  });

  //maximiezws the window on start
  mainWindow.maximize();

  //enables cros cross-origin so sharedArrayBuffer can be used for convolutions
  session.defaultSession.webRequest.onHeadersReceived((details, callback) => {
    callback({
      responseHeaders: {
        ...details.responseHeaders,
        'Cross-Origin-Opener-Policy': 'same-origin',
        'Cross-Origin-Embedder-Policy': 'require-corp',
        }
      });
    });

  // and load the index.html of the app.
  mainWindow.loadFile('Lab5.html');

  // Open the DevTools.
  globalShortcut.register("CmdOrCtrl+F12", () => {
    mainWindow.isFocused() && mainWindow.webContents.toggleDevTools();
  });

  if (process.platform === "win32") {
    app.setAppUserModelId("Convolution App");
  }
}

  //creates a Electron notification for app startup
  function startNotification (){
    new Notification({title:"Application Loaded", body:"Real-Time Convolutions with Mutlithreading App Loaded", icon:"tech.png"}).show();
  }

//creates a Electron notification for cancelling one of the dialog prompts
function cancelNotification(type){
  if(type === "select") {
    new Notification({title:"Select Cancelled", body:"Selection Cancelled!\nNo Image was Selected!", icon:"tech.png"}).show();
  }
  else {
    new Notification({title:"Save Cancelled", body:"Save Cancelled!\nNew Convoluted Image not Saved!", icon:"tech.png"}).show();
  }
}

//creates a Electron notification for informing the user that the image was successfully saved
function savedNotification (path){
  new Notification({title:"File Saved!", body:`New Convoluted Image saved at ${path}`, icon:"tech.png"}).show();
}

// This method will be called when Electron has finished
// initialization and is ready to create browser windows.
// Some APIs can only be used after this event occurs.
app.whenReady().then(createWindow).then(startNotification);

//handling the selectFile message from the rendere to select the file path to convolute
ipcMain.on("selectFile", (event, args) => {
  console.log(args);
  dialog.showOpenDialog(mainWindow, {title: "Select Image to Convolute", filters: [{ name: 'Images', extensions: ['jpg', 'png'] }], properties: ['openFile', 'dontAddToRecent'] }).then(function (response) {
    if (!response.canceled) {
      console.log(response.filePaths[0]);
      mainWindow.webContents.send("selectPath", response.filePaths[0]);
    } else {
      console.log("no file selected");
      cancelNotification("select");
    }
  });
});

//handling the saveFile message from the rendere to select the file path to save and then actually saves the file at that location
ipcMain.on("saveFile", (event, args) => {
  dialog.showSaveDialog({title: "Save Convoluted Image", filters: [{ name: 'PNG', extensions: ['png'] }, { name: 'JPG', extensions: ['jpg'] }],
                         properties:['dontAddToRecent']}).then(function (response) {
    if (!response.canceled) {
      fs.writeFile(response.filePath, args, 'base64', function(err) {
        if (err) {
            console.log(err);
        }
        else {
            console.log("The file was written");
            savedNotification(response.filePath);
            mainWindow.webContents.send("savePath", false);
        }
      });
    } else {
      console.log("no file selected");
      cancelNotification("save");
      mainWindow.webContents.send("savePath", false);
    }
  });
});

app.on('activate', function () {
  // On macOS it's common to re-create a window in the app when the
  // dock icon is clicked and there are no other windows open.
  if (BrowserWindow.getAllWindows().length === 0) createWindow();
})

// Quit when all windows are closed, except on macOS. There, it's common
// for applications and their menu bar to stay active until the user quits
// explicitly with Cmd + Q.
app.on('window-all-closed', function () {
  if (process.platform !== 'darwin') app.quit();
})

// In this file you can include the rest of your app's specific main process
// code. You can also put them in separate files and require them here.
